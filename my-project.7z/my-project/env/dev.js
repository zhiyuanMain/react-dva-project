module.exports = {
    'API_ASSETS': 'http://192.168.70.180'
}