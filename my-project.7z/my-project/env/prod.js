module.exports = {
    'API_ASSETS': ''
}