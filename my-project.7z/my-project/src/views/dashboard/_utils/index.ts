// 当前作用于下的utils
export const helper = (str: string) => str.toLowerCase()
