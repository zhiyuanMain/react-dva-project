import user from './user/zhCN'
export default {
  translation: {
    'Welcome.to.project': '欢迎',
    userMessagesUnread: 'Hello {{name}},  {{count}}条消息未读. 去看看。'
  },
  user
}
