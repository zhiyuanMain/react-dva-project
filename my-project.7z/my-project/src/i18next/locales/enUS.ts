import user from './user/enUS'
export default {
  translation: {
    'Welcome.to.project': 'Welcome',
    userMessagesUnread: 'Hello {{name}}, you have {{count}} unread message. Go to message.'
  },
  user
}
