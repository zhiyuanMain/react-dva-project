export default {
  allUser: 'All users'
}
