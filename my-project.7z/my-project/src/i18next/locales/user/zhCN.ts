export default {
  allUser: '全部用户'
}
