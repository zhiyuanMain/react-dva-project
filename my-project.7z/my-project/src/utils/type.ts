export const tuple = <T extends string[]>(...args: T) => args
