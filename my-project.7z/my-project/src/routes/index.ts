import createRoutes from './createRoutes'

export default createRoutes
