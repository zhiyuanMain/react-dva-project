# 项目初始化
## 安装依赖
```javascript
yarn install
```

## 开发模式
```javascript
yarn run start
```

## 打包
```javascript
yarn run build
```
